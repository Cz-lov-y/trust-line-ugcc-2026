# S06 — Statistical Sciences supplementary materials

Team S06: Zhuo Chen; Yue Tang; Yuen Song (Rain); Zihan Cao (Dalton).
Recommendation: Finch East, Yonge–Victoria Park, 7.101 km, BRT, with feasible future rail options considered.

This ZIP is the supplementary dataset/code/documentation upload required by the case brief p.13. The presentation and abstract PDF are uploaded separately. Rehearsal notes, timers, author-placeholder drafts and obsolete review correspondence are intentionally excluded.

## Required contents

1. **Part 1 dataset:** `datasets/Part1_Corridors_24.csv` has exactly one row per corridor and the active five indicators, original City scores, explicit min/mean scenarios, baseline/prerequisite metadata and equity estimate flags. `Part1_All24_Scenario_Scores.csv` has all 144 contextual scenario rows.
2. **Part 2 dataset:** `datasets/Part2_Technology_Comparison.csv` has BRT and LRT for the fixed corridor, with hypothetical cost, relative demand, assumed time saving, efficiency and status labels. `Part2_Weight_Sensitivity.csv` contains the declared input/method/profile cases.
3. **Executable source:** `outputs/project/code/replay_final_models_v1_0.py` is the compact offline entry point for both delivered models. Original numerical/scenario source is preserved alongside it.
4. **Outputs:** `outputs/project/outputs/` contains corridor selection, correlations, disputed-indicator stress, technology scores and sensitivity figures/tables.
5. **Documentation:** this README, `documentation/TRANSFORMATIONS.md`, `REFERENCES.md`, source registry, method JSON and original model reports document preparation, units, assumptions and limitations.

## Offline numerical reproduction

From the extracted ZIP's root:

```sh
python -m pip install -r requirements_replay.txt
python outputs/project/code/replay_final_models_v1_0.py
```

The entry point recomputes all 144 contextual corridor scores, common-baseline rank support and the technology scores/preference support and checks agreement with the supplied results. Its output is written to `outputs/project/outputs/final_replay_v1.0/`. It requires Python 3 and NumPy; validation used Python 3.12 / NumPy 2.5.5. Additional original scripts may need Matplotlib or GIS dependencies listed in `outputs/project/code/requirements_gis.txt`.

The replay reuses delivered CT-overlay estimates. It does not rebuild geometry. Large Census/RNF/GeoJSON acquisitions remain in the full repository, with source URLs/hashes and calculation lineage included here. The complete historical test suite and byte-level raw acquisition audits require that full repository, rather than this compact upload. Selected official City, Metrolinx and TTC PDFs are included to support source review.

## Sources and transformations

City 2024 evaluation tables supply corridor metadata and published standardized scores. Statistics Canada 2021 population/geography and 2020 LIM-AT counts support the custom area-weighted equity proxy. Metrolinx/YRRTC project evidence and TTC/City TSP reports contextualize the declared technology assumptions. Public URLs and source locators are in `outputs/project/data/source_log_v0.1.csv`, `REFERENCES.md` and evidence manifests.

Original source values are retained. Missing City values use separate observed-column-minimum and observed-column-mean scenarios. Equity is a custom CT uniform-density estimate, not official LIM prevalence; suppressed-count substitutions remain flagged. Its frozen 16-corridor z calibration is not a normality assumption. The 16/8 baseline split, disputed-ridership exclusion, policy weights and fixed seeds are explicit in the method files. `documentation/TRANSFORMATIONS.md` identifies active versus historical matrices.

## Interpretation

Task 1 excludes construction costs. Conditional corridors are assessed in their own baseline contexts rather than assigned invented Base-0 ranks. Task 2 uses declared hypothetical costs, relative demand and time savings; they are not verified total capital, absolute daily forecasts or guaranteed delivery. The 6–9-year milestone assumption has zero extra buffer in its upper case. BRT wins equal/capital-efficiency profiles; service-benefit priority can select LRT. Shared R in E=R/C and R, source transfer, principle-coverage gaps and normalization sensitivity are disclosed.

Actual AI assistance is disclosed in the presentation under the applicable permissions confirmed by the team. No physical prop, judge handout or recorded voice is part of the presentation plan. No competition upload is performed by this archive or its code.

Full source repository: https://github.com/Cz-lov-y/trust-line-ugcc-2026
