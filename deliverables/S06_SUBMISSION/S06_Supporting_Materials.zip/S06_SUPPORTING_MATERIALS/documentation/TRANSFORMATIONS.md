# Data preparation and active model map

## Part 1

- `corridor_master_v0.1.csv`: 24 original corridor definitions; City assumed construction lengths and network baseline metadata are retained.
- `city_standardized_scores_v0.1.csv`: original five City columns, with 98 published values and 22 blanks. These are standardized source scores, not physical km/h or passenger counts.
- The active five indicators are four City scores (`current_speed`, `unimproved_load`, `current_max_load`, `competitiveness`) plus `low_income_population_share_500m`. The disputed length-scaled `current_ridership` is excluded from the active five-criterion model; source values are not corrected or overwritten.
- Separate minimum/mean City input tables record the substitution assumptions. Missingness is not asserted to be random; substitutions are not observations.
- `supplemental_model_inputs_v0.5.csv`: all 24 equity estimates and numerator/denominator totals, with geometry/count-imputation flags. Population/LIM counts are allocated by intersected CT area fractions under uniform density. The numerator is divided by covered all-resident population, a custom proxy rather than official private-household LIM prevalence. Income reference is 2020; population/geography 2021. Complete same-CT DA sums are preferred for suppressed CTs; otherwise the authorized municipal CT-rate median is used with a mean sensitivity.
- Equity z=(fraction−0.13716878222779566)/0.02473132688714528, frozen on the 16 main corridors across stress comparisons. Z-scaling does not require or create a normal distribution. Published City normalization is retained.
- Common-baseline main IDs and eight conditional IDs are declared in `jane_stress_policy_v0.7.json`; conditional prerequisites/bundle results remain supplied. No unanchored common-base rank is invented for the eight.
- Scores are weighted sums; conservative tied ranks use tolerance 1e-12 and worst tied position for top-k. Two City methods × three profiles give six cases. PCG64 seed 20261121 selects identical cases across the paired models. Frequencies are scenario support, not population confidence. Broader block-weight sensitivity and correlation views are supplied separately.
- `datasets/Part1_Corridors_24.csv` is the active front-door table. `model_matrix_v0.5.csv` is the historical six-column scenario matrix, retained only for the paired baseline; do not use it to reintroduce `current_ridership` into the final five-criterion model.

## Part 2

- Fixed corridor 23, 7.101 km; BRT and LRT conditionally admitted, Subway excluded by the declared conservative delivery/depot policy, not demonstrated physical impossibility.
- User-selected scenario cost points CAD350M/CAD950M, relative ridership 1/1.2, one-way end-to-end savings 2.5/3.5 minutes and assumed 15 signals. No absolute passenger count, target before-trip observation or guaranteed priority benefit is fabricated.
- E=relative demand / cost in CAD billions; utilities use ratio to best and the stated weights. Cost per km is diagnostic only. Shared demand between E and R is disclosed. Alternative definitions/normalization, explicit profiles and stress cases remain sensitivity evidence.
- Fixed-input preference draws use PCG64 seed 20261122, Dirichlet(1,1,1), 10,000 draws. They describe an illustrative weight prior, not forecast accuracy or project-success probability.
- ECWE Table 19 Option 1 proportions allocate inside the unchanged cost points. A separately reported professional-services allowance is removed as a declared consultant-exclusion proxy; exact classification and source-to-target price/scope are not certified. This allocation is not independent validation of complete target capital.
- Four milestone durations 1–2, 1–2, 3–4 and 1 year sum to a 6–9-year scenario. The upper case starts January 2027 and reaches operational readiness December 2035 without extra delay buffer. No quantitative construction schedule is asserted.

For full reasoning, read `outputs/project/outputs/model_argument_v0.8/MODEL_JUSTIFICATION.md`, `outputs/project/outputs/jane_stress_v0.7/REPORT.md`, `outputs/project/outputs/task2_v0.3/BASELINE_MODEL.md` and `outputs/project/outputs/task2_v0.4/COMPETITION_PACKAGE.md`.
